package com.mercury.game.util;

/**
 * @Author: Risemy
 * Create Time:2020/7/30
 */
public interface LoginCallBack {
    void success(String msg);

    void fail(String msg);
}
