package com.mercury.game.util;

public class SpConfig {
    public static final String USER_ID = "USER_ID";
    public static final String USER_PHONE = "USER_PHONE";
    public static final String USER_CARD_ID = "USER_CARD_ID";
    public static final String TOKEN = "TOKEN";
}
