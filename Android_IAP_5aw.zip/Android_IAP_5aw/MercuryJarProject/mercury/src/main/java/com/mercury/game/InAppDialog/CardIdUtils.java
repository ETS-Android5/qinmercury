package com.mercury.game.InAppDialog;

public class CardIdUtils {

    public static String UpperCardId(String cardId){
        return cardId.toUpperCase();
    };

}
